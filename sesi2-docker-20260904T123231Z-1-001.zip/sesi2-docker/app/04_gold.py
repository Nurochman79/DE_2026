"""
Langkah 4 — Hitung angka bisnis. Ini zona GOLD.

Sama seperti Sesi 1: tiga tabel untuk tiga pertanyaan berbeda, memakai
window function. PostgreSQL dan SQLite kebetulan menulis window function
dengan cara yang sama persis, jadi bagian ini tidak berubah sama sekali.

Jalankan:  python 04_gold.py
"""

from db import ambil_satu, sambung

db = sambung()

with db.cursor() as k:
    k.execute("""
    DROP TABLE IF EXISTS gold_kategori;
    DROP TABLE IF EXISTS gold_per_jam;
    DROP TABLE IF EXISTS gold_produk;
    """)

# --- 1. Ringkasan per kategori -------------------------------------------
with db.cursor() as k:
    k.execute("""
    CREATE TABLE gold_kategori AS
    SELECT
        kategori,
        COUNT(*)                                  AS jumlah_order,
        SUM(jumlah)                               AS unit_terjual,
        SUM(total)                                AS penjualan,
        SUM(laba)                                 AS laba,
        ROUND(100.0 * SUM(laba) / SUM(total), 1)  AS margin_persen,
        ROUND(AVG(diskon_persen), 1)              AS rata_diskon,
        ROUND(100.0 * SUM(total) / SUM(SUM(total)) OVER (), 1) AS kontribusi_persen
    FROM silver_orders
    WHERE status <> 'batal'
    GROUP BY kategori
    ORDER BY penjualan DESC
    """)

# --- 2. Penjualan per jam, dengan total berjalan --------------------------
with db.cursor() as k:
    k.execute("""
    CREATE TABLE gold_per_jam AS
    SELECT
        jam,
        COUNT(*)     AS jumlah_order,
        SUM(total)   AS penjualan,
        SUM(SUM(total)) OVER (ORDER BY jam) AS penjualan_kumulatif
    FROM silver_orders
    WHERE status <> 'batal'
    GROUP BY jam
    ORDER BY jam
    """)

# --- 3. Peringkat produk --------------------------------------------------
with db.cursor() as k:
    k.execute("""
    CREATE TABLE gold_produk AS
    SELECT
        RANK() OVER (ORDER BY SUM(o.total) DESC) AS peringkat,
        p.nama,
        p.kategori,
        SUM(o.jumlah) AS unit_terjual,
        SUM(o.total)  AS penjualan,
        SUM(o.laba)   AS laba
    FROM silver_orders o
    JOIN dim_products p ON p.product_id = o.product_id
    WHERE o.status <> 'batal'
    GROUP BY p.product_id, p.nama, p.kategori
    ORDER BY peringkat
    """)

for tabel in ("gold_kategori", "gold_per_jam", "gold_produk"):
    n = ambil_satu(db, f"SELECT COUNT(*) FROM {tabel}")
    print(f"  {tabel:16s} {n:>3} baris")

a = ambil_satu(db, "SELECT SUM(penjualan) FROM gold_kategori")
b = ambil_satu(db, "SELECT SUM(penjualan) FROM gold_per_jam")
c = ambil_satu(db, "SELECT SUM(penjualan) FROM gold_produk")
assert a == b == c, "total dari tiga tabel gold harus sama"
print(f"\n  Total dari tiga tabel cocok: Rp {a:,}")

db.close()
