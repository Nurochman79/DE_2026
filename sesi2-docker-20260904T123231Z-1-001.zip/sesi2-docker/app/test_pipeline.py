"""
Tujuh pemeriksaan, sama seperti Sesi 1, tapi sekarang terhadap PostgreSQL.

Dijalankan DARI DALAM container:
    docker compose exec pipeline python -m pytest test_pipeline.py -v
"""

import pytest

from db import ambil_satu, sambung


@pytest.fixture
def db():
    koneksi = sambung()
    yield koneksi
    koneksi.close()


def test_tidak_ada_order_id_ganda(db):
    """Satu order_id cuma boleh muncul sekali."""
    baris = ambil_satu(db, "SELECT COUNT(*) FROM silver_orders")
    unik = ambil_satu(db, "SELECT COUNT(DISTINCT order_id) FROM silver_orders")
    assert baris == unik


def test_status_sudah_seragam(db):
    """Setelah dibersihkan hanya boleh ada tiga status, semuanya huruf kecil."""
    hasil = ambil_satu(
        db, "SELECT COUNT(*) FROM (SELECT DISTINCT status FROM silver_orders) x")
    assert hasil == 3


def test_semua_baris_silver_lolos_aturan(db):
    assert ambil_satu(db, "SELECT COUNT(*) FROM silver_orders WHERE jumlah <= 0") == 0
    assert ambil_satu(db, "SELECT COUNT(*) FROM silver_orders WHERE customer_id = ''") == 0
    assert ambil_satu(db, "SELECT COUNT(*) FROM silver_orders WHERE kategori IS NULL") == 0


def test_yang_ditolak_disimpan_bukan_dibuang(db):
    assert ambil_satu(db, "SELECT COUNT(*) FROM data_ditolak") > 0
    assert ambil_satu(db, "SELECT COUNT(*) FROM data_ditolak WHERE alasan IS NULL") == 0


def test_kolom_turunan_dihitung_benar(db):
    salah = ambil_satu(db, "SELECT COUNT(*) FROM silver_orders "
                           "WHERE total <> jumlah * harga_satuan")
    assert salah == 0


def test_tiga_tabel_gold_totalnya_sama(db):
    kategori = ambil_satu(db, "SELECT SUM(penjualan) FROM gold_kategori")
    per_jam = ambil_satu(db, "SELECT SUM(penjualan) FROM gold_per_jam")
    produk = ambil_satu(db, "SELECT SUM(penjualan) FROM gold_produk")
    manual = ambil_satu(db, "SELECT SUM(total) FROM silver_orders "
                            "WHERE status <> 'batal'")
    assert kategori == per_jam == produk == manual


def test_tidak_kehilangan_data_diam_diam(db):
    """Penolakan lebih dari 10 persen biasanya tanda aturannya yang salah."""
    ditolak = ambil_satu(db, "SELECT COUNT(*) FROM data_ditolak")
    silver = ambil_satu(db, "SELECT COUNT(*) FROM silver_orders")
    persen = 100 * ditolak / (ditolak + silver)
    assert persen < 10, f"{persen:.1f} persen order ditolak, terlalu banyak"
