"""
Satu tempat untuk urusan koneksi database.

Perhatikan: tidak ada satu pun password atau alamat server yang ditulis di
sini. Semuanya dibaca dari environment variable yang diisi oleh Docker
Compose. Inilah cara memindahkan pipeline yang sama antara laptop, server
uji, dan production tanpa mengubah kodenya.

Kalau dijalankan di luar container, nilai bawaan di bawah yang dipakai.
"""

import os
import time

import psycopg2

PENGATURAN = {
    "host": os.getenv("DB_HOST", "localhost"),
    "port": os.getenv("DB_PORT", "5432"),
    "dbname": os.getenv("DB_NAME", "tokobangalore"),
    "user": os.getenv("DB_USER", "postgres"),
    "password": os.getenv("DB_PASSWORD", "rahasia"),
}


def sambung(percobaan=15, jeda=2):
    """Sambung ke Postgres, sabar menunggu kalau servernya belum siap.

    Di dalam Docker, container pipeline bisa jalan lebih dulu daripada
    container database. Menunggu seperti ini lebih aman daripada berasumsi
    semuanya sudah siap.
    """
    for ke in range(1, percobaan + 1):
        try:
            koneksi = psycopg2.connect(**PENGATURAN)
            koneksi.autocommit = True
            if ke > 1:
                print(f"  database siap setelah menunggu {ke} kali")
            return koneksi
        except psycopg2.OperationalError as e:
            if ke == percobaan:
                print(f"  gagal menyambung ke {PENGATURAN['host']}:{PENGATURAN['port']}")
                raise
            print(f"  database belum siap, menunggu... ({ke}/{percobaan})")
            time.sleep(jeda)


def jalankan(sql, koneksi=None):
    """Jalankan satu perintah SQL."""
    tutup = koneksi is None
    koneksi = koneksi or sambung()
    with koneksi.cursor() as kursor:
        kursor.execute(sql)
    if tutup:
        koneksi.close()


def ambil_satu(koneksi, sql):
    with koneksi.cursor() as kursor:
        kursor.execute(sql)
        return kursor.fetchone()[0]


def ambil_semua(koneksi, sql):
    with koneksi.cursor() as kursor:
        kursor.execute(sql)
        return kursor.fetchall()
