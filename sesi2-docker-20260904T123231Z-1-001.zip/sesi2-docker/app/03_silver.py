"""
Langkah 3 — Bersihkan dan perkaya. Ini zona SILVER.

Isinya sama persis dengan Sesi 1. Yang berubah cuma dialek SQL-nya, karena
PostgreSQL menulis beberapa hal berbeda dari SQLite:

    SQLite                          PostgreSQL
    INSERT OR IGNORE                INSERT ... ON CONFLICT DO NOTHING
    strftime('%H', x)               EXTRACT(HOUR FROM x)
    strftime('%s', a) - ...         EXTRACT(EPOCH FROM (a - b))
    DATE(x)                         x::date
    CAST(x AS INTEGER)              x::int

Ini alasan kenapa memindahkan pipeline antar-database tidak pernah sesimpel
copy-paste, dan kenapa environment yang seragam itu penting.

Jalankan:  python 03_silver.py
"""

from db import ambil_satu, ambil_semua, sambung

db = sambung()

with db.cursor() as k:
    k.execute("""
    DROP TABLE IF EXISTS silver_orders CASCADE;
    CREATE TABLE silver_orders (
        order_id      TEXT PRIMARY KEY,   -- kunci ini yang mencegah data dobel
        customer_id   TEXT,
        product_id    TEXT,
        kategori      TEXT,
        jumlah        INTEGER,
        harga_satuan  INTEGER,
        harga_normal  INTEGER,
        total         INTEGER,
        laba          INTEGER,
        diskon_persen NUMERIC(5, 1),
        status        TEXT,
        tanggal       DATE,
        jam           INTEGER,
        telat_detik   INTEGER
    );

    DROP TABLE IF EXISTS data_ditolak;
    CREATE TABLE data_ditolak (
        order_id TEXT,
        alasan   TEXT
    );
    """)

# --- seragamkan status lalu gabung dengan katalog produk ------------------
with db.cursor() as k:
    k.execute("""
    DROP VIEW IF EXISTS orders_rapi CASCADE;
    CREATE VIEW orders_rapi AS
    SELECT
        b.order_id,
        b.customer_id,
        b.product_id,
        LOWER(TRIM(b.status))   AS status_rapi,   -- 'BAYAR ' jadi 'bayar'
        b.jumlah::int           AS jumlah,
        b.harga_satuan::int     AS harga_satuan,
        b.waktu_beli::timestamp AS waktu_beli,
        b.waktu_masuk::timestamp AS waktu_masuk,
        p.kategori,
        p.harga                 AS harga_normal,
        p.harga_modal
    FROM bronze_orders b
    LEFT JOIN dim_products p ON p.product_id = b.product_id;
    """)

# --- yang lolos masuk silver ---------------------------------------------
with db.cursor() as k:
    k.execute("""
    INSERT INTO silver_orders
    SELECT
        order_id,
        customer_id,
        product_id,
        kategori,
        jumlah,
        harga_satuan,
        harga_normal,
        jumlah * harga_satuan                     AS total,
        jumlah * (harga_satuan - harga_modal)     AS laba,
        ROUND(100.0 * (harga_normal - harga_satuan) / harga_normal, 1) AS diskon_persen,
        status_rapi,
        waktu_beli::date                          AS tanggal,
        EXTRACT(HOUR FROM waktu_beli)::int        AS jam,
        EXTRACT(EPOCH FROM (waktu_masuk - waktu_beli))::int AS telat_detik
    FROM orders_rapi
    WHERE jumlah > 0
      AND customer_id <> ''
      AND kategori IS NOT NULL
      AND status_rapi IN ('bayar', 'kirim', 'batal')
    ON CONFLICT (order_id) DO NOTHING
    """)

# --- yang gagal dicatat beserta alasannya --------------------------------
with db.cursor() as k:
    k.execute("""
    INSERT INTO data_ditolak
    SELECT DISTINCT order_id,
           CASE
               WHEN jumlah <= 0      THEN 'jumlah harus lebih dari 0'
               WHEN customer_id = '' THEN 'customer_id kosong'
               WHEN kategori IS NULL THEN 'product_id tidak ada di katalog: ' || product_id
               ELSE 'status tidak dikenal: ' || status_rapi
           END
    FROM orders_rapi
    WHERE jumlah <= 0
       OR customer_id = ''
       OR kategori IS NULL
       OR status_rapi NOT IN ('bayar', 'kirim', 'batal')
    """)

# --- laporan --------------------------------------------------------------
bronze = ambil_satu(db, "SELECT COUNT(*) FROM bronze_orders")
unik = ambil_satu(db, "SELECT COUNT(DISTINCT order_id) FROM bronze_orders")
tolak = ambil_satu(db, "SELECT COUNT(*) FROM data_ditolak")
silver = ambil_satu(db, "SELECT COUNT(*) FROM silver_orders")
variasi = ambil_satu(db, "SELECT COUNT(DISTINCT status) FROM bronze_orders")

print(f"  bronze          : {bronze:>5} baris masuk")
print(f"  cara tulis status: {variasi:>4} variasi, diseragamkan jadi 3")
print(f"  kiriman ganda   : {bronze - unik:>5} baris")
print(f"  order unik      : {unik:>5} baris")
print(f"  ditolak         : {tolak:>5} baris")
print(f"  silver          : {silver:>5} baris")
print(f"\n  lolos           : {silver / unik:.1%} dari order yang unik")

assert unik - tolak == silver

print("\n  Alasan penolakan:")
for alasan, n in ambil_semua(db, "SELECT alasan, COUNT(*) FROM data_ditolak "
                                 "GROUP BY alasan ORDER BY 2 DESC"):
    print(f"    {n:>3}  {alasan}")

db.close()
