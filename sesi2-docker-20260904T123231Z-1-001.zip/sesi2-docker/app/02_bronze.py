"""
Langkah 2 — Masukkan CSV ke PostgreSQL, apa adanya. Ini zona BRONZE.

Bedanya dengan Sesi 1: databasenya bukan lagi file SQLite di folder kita,
tapi PostgreSQL yang jalan di container terpisah. Kodenya hampir sama,
yang berubah cuma cara menyambungnya.

Jalankan:  python 02_bronze.py
"""

import csv
from pathlib import Path

from db import sambung

DATA = Path(__file__).parent / "data"

db = sambung()

with db.cursor() as k:
    k.execute("""
    DROP TABLE IF EXISTS bronze_orders;
    CREATE TABLE bronze_orders (
        order_id     TEXT,
        customer_id  TEXT,
        product_id   TEXT,
        jumlah       TEXT,      -- sengaja TEXT: bronze menerima apa adanya
        harga_satuan TEXT,
        status       TEXT,
        waktu_beli   TEXT,
        waktu_masuk  TEXT
    );

    DROP TABLE IF EXISTS dim_products CASCADE;
    CREATE TABLE dim_products (
        product_id  TEXT PRIMARY KEY,
        nama        TEXT,
        kategori    TEXT,
        harga       INTEGER,
        harga_modal INTEGER
    );

    DROP TABLE IF EXISTS dim_customers CASCADE;
    CREATE TABLE dim_customers (
        customer_id TEXT PRIMARY KEY,
        kota        TEXT
    );
    """)


def muat(nama_file, tabel, jumlah_kolom):
    with (DATA / nama_file).open(encoding="utf-8") as f:
        pembaca = csv.reader(f)
        next(pembaca)                                # lewati baris header
        baris = list(pembaca)
    tanda_tanya = ",".join(["%s"] * jumlah_kolom)
    with db.cursor() as k:
        k.executemany(f"INSERT INTO {tabel} VALUES ({tanda_tanya})", baris)
    print(f"  {tabel:16s} {len(baris):>5} baris masuk")


muat("orders.csv", "bronze_orders", 8)
muat("products.csv", "dim_products", 5)
muat("customers.csv", "dim_customers", 2)

db.close()
print("\nSelesai. Datanya sekarang ada di PostgreSQL, bukan di laptopmu.")
print("Buka pgAdmin di http://localhost:5050 kalau mau lihat isinya.")
