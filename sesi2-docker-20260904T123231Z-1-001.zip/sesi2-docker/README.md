# Sesi 2 — Environment Docker untuk Pipeline Tokobangalore

Pipeline yang sama dengan Sesi 1, dipindahkan ke dalam container. Databasenya
naik dari SQLite jadi PostgreSQL, dan semuanya dinyalakan dengan satu perintah.

> **Baru pertama kali menjalankan? Buka `PANDUAN.md`.**
> Isinya langkah demi langkah, lengkap dengan tampilan layar yang seharusnya
> muncul. README ini lebih cocok dipakai sebagai rujukan setelah kamu sekali
> menjalankannya.

## Yang dibutuhkan

Cuma Docker Desktop. Python tidak perlu dipasang di laptop.

## Cara menjalankan

```bash
docker compose up -d --build
docker compose exec pipeline python 01_buat_data.py
docker compose exec pipeline python 02_bronze.py
docker compose exec pipeline python 03_silver.py
docker compose exec pipeline python 04_gold.py
docker compose exec pipeline python 05_lihat_hasil.py
docker compose exec pipeline python -m pytest test_pipeline.py -v
```

pgAdmin ada di `http://localhost:5050`.

## Tiga layanan

| Layanan | Image | Port ke laptop | Ada di jaringan |
| --- | --- | --- | --- |
| `postgres` | `postgres:16-alpine` | tidak ada | data, admin |
| `pgadmin` | `dpage/pgadmin4:8.12` | 5050 | admin |
| `pipeline` | dibangun dari `Dockerfile` | tidak ada | data |

Cuma pgAdmin yang bisa dibuka dari laptop. Database tidak membuka port sama
sekali, dan cuma bisa dijangkau dari dalam jaringan Docker.

## Isi folder

| File | Untuk apa |
| --- | --- |
| `PANDUAN.md` | Langkah demi langkah, baca ini duluan |
| `README.md` | Rujukan |
| `Dockerfile` | Resep membuat image pipeline |
| `docker-compose.yml` | Tiga layanan, dua jaringan, dua volume |
| `.env` | Nama database, user, sandi |
| `.dockerignore` | File yang tidak ikut masuk ke image |
| `app/db.py` | Satu tempat untuk urusan koneksi |
| `app/01` sampai `05` | Skrip pipeline |
| `app/test_pipeline.py` | Tujuh pemeriksaan |

## Empat hal yang diajarkan file ini

**1. Urutan di Dockerfile menentukan kecepatan build**

`requirements.txt` disalin dan dipasang lebih dulu, kode belakangan. Hasilnya
terukur:

| Yang diubah | Lama build |
| --- | --- |
| tidak ada | 3 detik |
| satu baris kode | **1 detik** |
| `requirements.txt` | 11 detik |

Kalau urutannya dibalik, tiap perubahan kode memakan 11 detik, bukan 1 detik.

**2. Volume membuat data hidup lebih lama daripada container**

`docker compose down` menghapus semua container. Data tetap ada, karena
disimpan di volume `pgdata`. Yang menghapusnya cuma `down -v`.

**3. Jaringan terpisah membatasi siapa bisa menjangkau siapa**

```
pipeline  --[jaringan_data]-->  postgres
pgadmin   --[jaringan_admin]--> postgres
pipeline  --X--                 pgadmin
```

Dibuktikan dari dalam container:

```bash
docker compose exec pipeline python -c "import socket; socket.create_connection(('pgadmin', 80), timeout=3)"
# socket.gaierror: Name or service not known
```

**4. Healthcheck mencegah container start terlalu cepat**

Postgres butuh beberapa detik sebelum siap menerima koneksi. `depends_on`
dengan `condition: service_healthy` membuat pipeline menunggu, bukan langsung
jalan lalu gagal.

## Angka yang keluar

```
bronze          :  2053 baris masuk
kiriman ganda   :    53 baris
order unik      :  2000 baris
ditolak         :    90 baris
silver          :  1910 baris

TOTAL PENJUALAN  Rp 630.614.700
TOTAL LABA       Rp 159.089.700   margin 25,2%
```

Sama persis dengan Sesi 1, padahal databasenya sudah pindah dari SQLite ke
PostgreSQL. Itu buktinya bahwa yang dipindahkan bukan cuma kodenya, tapi
seluruh environmentnya.

## SQL-nya tidak sepenuhnya sama

Memindahkan pipeline antar-database tidak pernah sesederhana copy-paste.
Yang harus diubah dari Sesi 1:

| SQLite | PostgreSQL |
| --- | --- |
| `INSERT OR IGNORE` | `INSERT ... ON CONFLICT DO NOTHING` |
| `strftime('%H', x)` | `EXTRACT(HOUR FROM x)` |
| `strftime('%s', a) - strftime('%s', b)` | `EXTRACT(EPOCH FROM (a - b))` |
| `DATE(x)` | `x::date` |
| `CAST(x AS INTEGER)` | `x::int` |

Window function kebetulan ditulis sama di keduanya, jadi `04_gold.py` hampir
tidak berubah.
