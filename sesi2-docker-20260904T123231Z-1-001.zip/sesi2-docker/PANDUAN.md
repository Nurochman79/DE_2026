# Panduan Menjalankan — Sesi 2

Pipeline yang sama dengan Sesi 1, tapi sekarang jalan di dalam container dan
datanya masuk ke PostgreSQL, bukan file SQLite.

---

## Persiapan

Yang dibutuhkan cuma Docker Desktop. Python tidak perlu dipasang di laptop —
Python-nya ada di dalam container.

```bash
docker --version
docker compose version
```

Kalau muncul errornya "cannot find the file specified", berarti Docker Desktop
belum dinyalakan. Buka dulu aplikasinya, tunggu sampai ikonnya hijau.

Masuk ke folder ini:

```bash
cd sesi2-docker
```

---

## Langkah 1 — Nyalakan semuanya

```bash
docker compose up -d --build
```

Yang muncul (dipotong):

```
 sesi2-docker-pipeline  Built
 Network sesi2-docker_jaringan_data   Created
 Network sesi2-docker_jaringan_admin  Created
 Volume "sesi2-docker_pgdata"         Created
 Container toko-postgres  Started
 Container toko-postgres  Healthy
 Container toko-pipeline  Started
 Container toko-pgadmin   Started
```

**Apa yang terjadi:** satu perintah membangun image pipeline, membuat dua
jaringan, dua volume, lalu menyalakan tiga container dengan urutan yang benar.

**Yang perlu dilihat:** baris `toko-postgres Healthy` muncul **sebelum**
pipeline dan pgadmin dinyalakan. Itu karena keduanya menunggu database
benar-benar siap, bukan sekadar prosesnya hidup.

Cek statusnya:

```bash
docker compose ps
```

```
NAME            STATUS                    PORTS
toko-pgadmin    Up 12 seconds             0.0.0.0:5050->80/tcp
toko-pipeline   Up 56 seconds
toko-postgres   Up About a minute (healthy)   5432/tcp
```

Perhatikan kolom PORTS. Cuma pgAdmin yang punya `0.0.0.0:5050->80`. Postgres
dan pipeline tidak membuka satu pun port ke laptop.

---

## Langkah 2 — Jalankan pipeline di dalam container

Perhatikan bentuk perintahnya. Tidak lagi `python 01_buat_data.py`, tapi
`docker compose exec pipeline python 01_buat_data.py`. Artinya: jalankan
perintah ini di dalam container bernama `pipeline`.

```bash
docker compose exec pipeline python 01_buat_data.py
docker compose exec pipeline python 02_bronze.py
docker compose exec pipeline python 03_silver.py
docker compose exec pipeline python 04_gold.py
docker compose exec pipeline python 05_lihat_hasil.py
```

Hasil langkah 3:

```
  bronze          :  2053 baris masuk
  cara tulis status:   10 variasi, diseragamkan jadi 3
  kiriman ganda   :    53 baris
  order unik      :  2000 baris
  ditolak         :    90 baris
  silver          :  1910 baris

  lolos           : 95.5% dari order yang unik
```

Hasil langkah 5:

```
  TOTAL PENJUALAN  Rp   630,614,700
  TOTAL LABA       Rp   159,089,700   margin 25.2%
```

**Yang perlu dilihat:** angkanya sama persis dengan Sesi 1. Padahal
databasenya sudah beda, Python-nya beda, dan jalannya di dalam container.

Itulah yang dimaksud environment yang reproducible.

---

## Langkah 3 — Lihat isinya lewat pgAdmin

Buka browser ke `http://localhost:5050`.

Login: alamat email dan sandi ada di file `.env`.

Tambahkan server baru dengan pengaturan:

| Isian | Nilai |
| --- | --- |
| Name | bebas, misalnya `toko` |
| Host | `postgres` |
| Port | `5432` |
| Database | `tokobangalore` |
| Username | `toko` |
| Password | `rahasia123` |

**Yang perlu dilihat:** Host diisi `postgres`, bukan `localhost` atau alamat
IP. Itu nama layanan di `docker-compose.yml`. Docker yang menerjemahkannya
jadi alamat yang benar.

---

## Langkah 4 — Buktikan jaringannya benar-benar terpisah

Pipeline seharusnya bisa menjangkau database, tapi tidak bisa menjangkau
pgAdmin.

```bash
docker compose exec pipeline python -c "import socket; socket.create_connection(('postgres', 5432), timeout=3); print('postgres: bisa')"
```

```
postgres: bisa
```

Sekarang coba ke pgAdmin:

```bash
docker compose exec pipeline python -c "import socket; socket.create_connection(('pgadmin', 80), timeout=3)"
```

```
socket.gaierror: [Errno -2] Name or service not known
```

**Apa artinya:** nama `pgadmin` tidak dikenal dari dalam container pipeline,
karena keduanya berada di jaringan yang berbeda. Ini bukan error, ini memang
yang kita rancang.

Kalau ketiganya ditaruh di satu jaringan, semua bisa saling menjangkau. Di
production itu artinya satu container yang jebol bisa menjangkau seluruh
sistem.

---

## Langkah 5 — Buktikan datanya tidak hilang

Hapus semua containernya:

```bash
docker compose down
```

Cek volume masih ada:

```bash
docker volume ls --filter name=sesi2-docker
```

```
sesi2-docker_pgadmin_data
sesi2-docker_pgdata
```

Nyalakan lagi, lalu cek datanya:

```bash
docker compose up -d
docker compose exec pipeline python 05_lihat_hasil.py
```

```
  TOTAL PENJUALAN  Rp   630,614,700
```

**Apa yang terjadi:** containernya sudah dihapus dan dibuat ulang, tapi
datanya masih utuh. Yang menyimpan data bukan container, tapi volume.

**Coba yang ini kalau berani:** `docker compose down -v`. Tambahan `-v` ikut
menghapus volume. Setelah itu datanya benar-benar hilang, dan kamu harus
mengulang dari langkah 2.

---

## Langkah 6 — Rasakan efek layer caching

Bangun ulang tanpa mengubah apa pun:

```bash
docker compose build pipeline
```

Sekitar **3 detik**. Semua lapisan diambil dari simpanan.

Sekarang ubah satu baris di `app/05_lihat_hasil.py`, lalu bangun lagi:

```bash
docker compose build pipeline
```

Sekitar **1 detik**. Dependency tidak dipasang ulang, karena
`requirements.txt` tidak berubah.

Sekarang ubah `app/requirements.txt`, lalu bangun lagi:

Sekitar **11 detik**. Pip memasang ulang semuanya.

**Kenapa bisa begitu:** buka `Dockerfile`, perhatikan urutannya.
`requirements.txt` disalin dan dipasang lebih dulu, kode belakangan. Kode
berubah puluhan kali sehari, dependency jarang berubah.

**Coba balik urutannya** jadi seperti ini:

```dockerfile
COPY app/ .
RUN pip install --no-cache-dir -r requirements.txt
```

Lalu ubah satu baris kode dan bangun ulang. Sekarang tiap perubahan kode
sekecil apa pun memakan 11 detik, bukan 1 detik. Di proyek besar dengan
puluhan dependency, selisihnya bisa menit.

Kembalikan urutan aslinya setelah selesai mencoba.

---

## Langkah 7 — Jalankan pemeriksaan

```bash
docker compose exec pipeline python -m pytest test_pipeline.py -v
```

```
7 passed
```

---

## Kalau ada masalah

**`cannot find the file specified` waktu menjalankan docker**
Docker Desktop belum menyala. Buka aplikasinya, tunggu ikonnya hijau.

**`port is already allocated`**
Ada yang sudah memakai port 5050. Ubah di `docker-compose.yml` jadi
`"5051:80"`, lalu `docker compose up -d` lagi.

**`does not appear to be a valid email address` di log pgadmin**
Nilai `PGADMIN_EMAIL` di `.env` tidak berbentuk email wajar. pgAdmin menolak
domain seperti `.local`. Pakai yang berakhiran `.com`.

**`could not translate host name "postgres"`**
Skripnya dijalankan dari laptop, bukan dari dalam container. Nama `postgres`
cuma dikenal di dalam jaringan Docker. Pakai `docker compose exec pipeline
python ...`.

**Mau benar-benar mulai dari nol**
```bash
docker compose down -v
docker compose up -d --build
```
Tambahan `-v` ikut menghapus volume, jadi databasenya kosong lagi.

---

## Ringkasan perintah

```bash
docker compose up -d --build

docker compose exec pipeline python 01_buat_data.py
docker compose exec pipeline python 02_bronze.py
docker compose exec pipeline python 03_silver.py
docker compose exec pipeline python 04_gold.py
docker compose exec pipeline python 05_lihat_hasil.py
docker compose exec pipeline python -m pytest test_pipeline.py -v

docker compose ps          # lihat status
docker compose logs -f     # lihat log berjalan
docker compose down        # matikan, data tetap ada
docker compose down -v     # matikan, data ikut dihapus
```
