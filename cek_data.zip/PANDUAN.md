# Panduan Menjalankan — Langkah demi Langkah

Ikuti dari atas ke bawah. Tiap langkah memakai hasil langkah sebelumnya, jadi
urutannya tidak boleh dibalik.

---

## Persiapan

Buka terminal, lalu masuk ke folder ini:

```bash
cd sesi1-pipeline
```

Pastikan Python-nya 3.9 ke atas:

```bash
python --version
```

Pasang satu paket, cukup sekali seumur hidup:

```bash
pip install pytest
```

Tidak perlu memasang database. SQLite sudah ikut di dalam Python.

---

## Langkah 1 — Bikin data dummy

```bash
python 01_buat_data.py
```

Yang muncul di layar:

```
  products.csv        20 baris
  customers.csv      100 baris
  orders.csv        2053 baris

Data siap di folder data/. Coba buka orders.csv pakai Excel.
```

**Apa yang terjadi:** tiga file CSV dibuat di folder `data/`. Ini kita anggap
kiriman dari sistem lain.

**Yang perlu dilihat:** buka `data/orders.csv` pakai Excel. Perhatikan kolom
`status`. Isinya tidak seragam: ada `bayar`, ada `BAYAR ` dengan huruf besar
dan spasi, ada ` Bayar`. Ini yang nanti kita rapikan.

Kenapa 2053, bukan 2000? Karena ada 53 order yang dikirim dua kali oleh
sistem sumber.

---

## Langkah 2 — Masukkan ke database

```bash
python 02_bronze.py
```

Yang muncul:

```
  bronze_orders     2053 baris masuk
  dim_products        20 baris masuk
  dim_customers      100 baris masuk

Selesai. Buka tokobangalore.db pakai DBeaver kalau mau lihat isinya.
```

**Apa yang terjadi:** isi CSV dipindah ke database `tokobangalore.db`, apa
adanya. Tidak ada yang dibersihkan di sini.

**Yang perlu dilihat:** buka `02_bronze.py`, perhatikan bahwa semua kolom
di tabel `bronze_orders` bertipe `TEXT`, bahkan `jumlah` dan `harga_satuan`.
Ini disengaja. Zona bronze menerima apa pun yang dikirim sumber tanpa
menghakimi.

---

## Langkah 3 — Bersihkan dan perkaya

```bash
python 03_silver.py
```

Yang muncul:

```
  bronze          :  2053 baris masuk
  cara tulis status:   10 variasi, diseragamkan jadi 3
  kiriman ganda   :    53 baris
  order unik      :  2000 baris
  ditolak         :    90 baris
  silver          :  1910 baris

  lolos           : 95.5% dari order yang unik

  Alasan penolakan:
     33  jumlah harus lebih dari 0
     22  status tidak dikenal: pending
     18  product_id tidak ada di katalog: P99
     17  customer_id kosong
```

**Apa yang terjadi:** ini langkah paling padat. Lima hal sekaligus:
status diseragamkan, data digabung dengan katalog produk, kolom baru
dihitung, kiriman ganda dibuang, dan yang salah disaring.

**Yang perlu dilihat:** angka `2000 − 90 = 1910` harus pas. Kalau tidak pas,
skripnya akan berhenti sendiri karena ada `assert` di dalamnya.

Perhatikan juga alasan penolakan. Empat jenis, dan semuanya masalah yang
benar-benar sering muncul di pekerjaan sehari-hari.

**Coba ini:** jalankan `python 03_silver.py` sekali lagi. Angkanya tidak
berubah sama sekali. Itu yang disebut aman diulang.

---

## Langkah 4 — Hitung angka bisnis

```bash
python 04_gold.py
```

Yang muncul:

```
  gold_kategori      5 baris
  gold_per_jam       8 baris
  gold_produk       20 baris

  Total dari tiga tabel cocok: Rp 630,614,700
```

**Apa yang terjadi:** 1910 baris transaksi diringkas jadi tiga tabel kecil,
masing-masing menjawab pertanyaan berbeda.

**Yang perlu dilihat:** baris terakhir. Total dari tiga sudut pandang yang
berbeda harus sama persis. Kalau berbeda, berarti ada baris yang hilang saat
penggabungan tabel.

---

## Langkah 5 — Lihat hasilnya

```bash
python 05_lihat_hasil.py
```

Yang muncul (dipotong):

```
PER KATEGORI                 order    penjualan        laba  margin  kontribusi
  elektronik                 365  302,259,500  48,424,500   16.0%       47.9%
  fashion                    311  115,100,700  52,695,700   45.8%       18.3%
  ...
  TOTAL PENJUALAN  Rp   630,614,700
  TOTAL LABA       Rp   159,089,700   margin 25.2%
```

**Yang perlu dilihat:** elektronik penjualannya paling besar, tapi marginnya
paling tipis. Fashion penjualannya jauh lebih kecil, tapi labanya justru lebih
besar.

Temuan seperti ini cuma muncul karena pipeline ikut membawa harga modal dari
tabel katalog. Kalau cuma menjumlahkan penjualan, tidak akan kelihatan.

---

## Langkah 6 — Hitung yang hilang karena telat

```bash
python 06_data_telat.py
```

Yang muncul:

```
  batas tunggu   transaksi hilang   penjualan tercatat      selisih
    1 menit         239 transaksi     Rp  544,964,950   Rp 85,649,750
    5 menit         208 transaksi     Rp  560,826,200   Rp 69,788,500
   15 menit         110 transaksi     Rp  593,363,500   Rp 37,251,200
   30 menit          37 transaksi     Rp  617,127,850   Rp 13,486,850
   60 menit           0 transaksi     Rp  630,614,700   Rp          0
```

**Apa yang terjadi:** sebagian data baru sampai puluhan menit setelah
transaksi. Kalau pipeline tidak mau menunggu selama itu, data yang telat tidak
ikut terhitung.

**Pertanyaan untuk kamu:** berapa batas tunggu yang kamu pilih untuk dashboard
penjualan harian? Lalu untuk deteksi penipuan kartu kredit, apakah jawabannya
sama?

---

## Langkah 7 — Buktikan angkanya benar

```bash
python -m pytest test_pipeline.py -v
```

Yang muncul:

```
7 passed
```

**Apa yang terjadi:** tujuh pemeriksaan dijalankan, misalnya memastikan tidak
ada `order_id` yang dobel dan total tiga tabel gold sama persis.

**Coba rusak dengan sengaja.** Buka `03_silver.py`, cari baris ini:

```sql
LOWER(TRIM(b.status))  AS status_rapi,
```

Ganti jadi `b.status  AS status_rapi,` yaitu tanpa penyeragaman. Lalu:

```bash
python 03_silver.py
python 04_gold.py
python -m pytest test_pipeline.py -v
```

Yang terjadi: silver anjlok dari 1910 jadi 603 baris, dan 1397 order ditolak
dengan alasan "status tidak dikenal: BAYAR". Tanpa penyeragaman, semua
penulisan yang tidak persis huruf kecil jadi ditolak.

Testnya merah di `test_tidak_kehilangan_data_diam_diam`.

Perhatikan baik-baik: enam test lainnya tetap hijau. Semuanya cuma memeriksa
bahwa data yang MASUK silver sudah bersih, dan memang bersih. Yang tidak
diperiksa adalah berapa banyak yang tidak masuk. Pipeline yang membuang 70
persen data tetap menghasilkan silver yang rapi.

Kembalikan `LOWER(TRIM(...))` setelah selesai mencoba, lalu jalankan ulang
langkah 3 dan 4.

---

## Tambahan — Periksa kesehatan data

```bash
python cek_data.py
```

Menjalankan 21 pemeriksaan tambahan terhadap data dan hasil pipeline. Berguna kalau
kamu mengubah aturan di `03_silver.py` dan ingin memastikan tidak ada yang
rusak.

---

## Kalau ada masalah

**`python` tidak dikenal**
Coba `python3` atau `py`. Di Windows biasanya `py`.

**`No module named pytest`**
Belum dipasang. Jalankan `pip install pytest`.

**`no such table: bronze_orders`**
Langkah 2 belum dijalankan, atau dijalankan dari folder yang salah. Pastikan
kamu berada di dalam folder `sesi1-pipeline`.

**Angka di layarmu berbeda dengan panduan ini**
Hapus `tokobangalore.db` dan folder `data/`, lalu ulangi dari langkah 1.
Seed dikunci di 42, jadi hasilnya pasti sama.

**Mau mengulang dari nol**
```bash
rm tokobangalore.db
python 02_bronze.py
```
Tidak perlu mengulang langkah 1 kecuali kamu memang ingin data baru.

---

## Ringkasan perintah

```bash
pip install pytest

python 01_buat_data.py
python 02_bronze.py
python 03_silver.py
python 04_gold.py
python 05_lihat_hasil.py
python 06_data_telat.py
python -m pytest test_pipeline.py -v
```
