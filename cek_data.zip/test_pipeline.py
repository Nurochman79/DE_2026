"""
Enam pemeriksaan supaya kita tidak cuma percaya bahwa pipeline-nya benar.

Jalankan dulu 01 sampai 04, baru:  python -m pytest test_pipeline.py -v
"""

import sqlite3

import pytest


@pytest.fixture
def db():
    koneksi = sqlite3.connect("tokobangalore.db")
    yield koneksi
    koneksi.close()


def satu(db, sql):
    return db.execute(sql).fetchone()[0]


def test_tidak_ada_order_id_ganda(db):
    """Satu order_id cuma boleh muncul sekali. Kalau dobel, penjualan ikut dobel."""
    baris = satu(db, "SELECT COUNT(*) FROM silver_orders")
    unik = satu(db, "SELECT COUNT(DISTINCT order_id) FROM silver_orders")
    assert baris == unik


def test_status_sudah_seragam(db):
    """Setelah dibersihkan hanya boleh ada tiga status, semuanya huruf kecil."""
    status = [r[0] for r in db.execute("SELECT DISTINCT status FROM silver_orders")]
    assert sorted(status) == ["batal", "bayar", "kirim"]


def test_semua_baris_silver_lolos_aturan(db):
    """Tidak boleh ada jumlah nol, customer kosong, atau produk di luar katalog."""
    assert satu(db, "SELECT COUNT(*) FROM silver_orders WHERE jumlah <= 0") == 0
    assert satu(db, "SELECT COUNT(*) FROM silver_orders WHERE customer_id = ''") == 0
    assert satu(db, "SELECT COUNT(*) FROM silver_orders WHERE kategori IS NULL") == 0


def test_yang_ditolak_disimpan_bukan_dibuang(db):
    """Setiap baris yang gagal harus punya catatan alasannya."""
    assert satu(db, "SELECT COUNT(*) FROM data_ditolak") > 0
    assert satu(db, "SELECT COUNT(*) FROM data_ditolak WHERE alasan IS NULL") == 0


def test_kolom_turunan_dihitung_benar(db):
    """total harus sama dengan jumlah x harga_satuan, tanpa kecuali."""
    salah = satu(db, "SELECT COUNT(*) FROM silver_orders "
                     "WHERE total <> jumlah * harga_satuan")
    assert salah == 0


def test_tiga_tabel_gold_totalnya_sama(db):
    """Dipotong per kategori, per jam, atau per produk, totalnya harus sama."""
    kategori = satu(db, "SELECT SUM(penjualan) FROM gold_kategori")
    per_jam = satu(db, "SELECT SUM(penjualan) FROM gold_per_jam")
    produk = satu(db, "SELECT SUM(penjualan) FROM gold_produk")
    manual = satu(db, "SELECT SUM(total) FROM silver_orders WHERE status <> 'batal'")
    assert kategori == per_jam == produk == manual


def test_tidak_kehilangan_data_diam_diam(db):
    """Penolakan yang terlalu banyak biasanya tanda aturannya yang salah,
    bukan datanya. Ambang 10 persen ini yang menangkapnya.

    Test ini penting: lima test di atas cuma memeriksa data yang MASUK
    silver sudah bersih. Tidak ada yang memeriksa berapa banyak yang
    tidak masuk. Pipeline yang membuang 70 persen data tetap menghasilkan
    silver yang bersih.
    """
    ditolak = satu(db, "SELECT COUNT(*) FROM data_ditolak")
    silver = satu(db, "SELECT COUNT(*) FROM silver_orders")
    persen = 100 * ditolak / (ditolak + silver)
    assert persen < 10, f"{persen:.1f} persen order ditolak, terlalu banyak"
