"""
Langkah 4 — Hitung angka yang dibaca bisnis. Ini zona GOLD.

Tiga tabel, tiga pertanyaan yang berbeda:

  gold_kategori       kategori mana yang paling untung?
  gold_per_jam        jam berapa toko paling ramai?
  gold_produk         produk mana yang paling laku, dan seberapa dominan?

Yang batal tidak dihitung sebagai penjualan.

Di sini kita mulai pakai window function (SUM OVER, RANK OVER). Bedanya
dengan GROUP BY biasa: hasilnya tetap satu baris per kelompok, tapi bisa
melihat baris lain untuk menghitung kumulatif dan peringkat.

Jalankan:  python 04_gold.py
"""

import sqlite3

db = sqlite3.connect("tokobangalore.db")

db.executescript("""
DROP TABLE IF EXISTS gold_kategori;
DROP TABLE IF EXISTS gold_per_jam;
DROP TABLE IF EXISTS gold_produk;
""")

# =========================================================================
# 1. Ringkasan per kategori, lengkap dengan margin dan kontribusi
# =========================================================================
db.execute("""
CREATE TABLE gold_kategori AS
SELECT
    kategori,
    COUNT(*)                                  AS jumlah_order,
    SUM(jumlah)                               AS unit_terjual,
    SUM(total)                                AS penjualan,
    SUM(laba)                                 AS laba,
    ROUND(100.0 * SUM(laba) / SUM(total), 1)  AS margin_persen,
    ROUND(AVG(diskon_persen), 1)              AS rata_diskon,
    -- kontribusi terhadap penjualan seluruh toko
    ROUND(100.0 * SUM(total) / SUM(SUM(total)) OVER (), 1) AS kontribusi_persen
FROM silver_orders
WHERE status <> 'batal'
GROUP BY kategori
ORDER BY penjualan DESC
""")

# =========================================================================
# 2. Penjualan per jam, dengan total berjalan
# =========================================================================
db.execute("""
CREATE TABLE gold_per_jam AS
SELECT
    jam,
    COUNT(*)     AS jumlah_order,
    SUM(total)   AS penjualan,
    -- total berjalan dari jam paling pagi sampai jam ini
    SUM(SUM(total)) OVER (ORDER BY jam) AS penjualan_kumulatif
FROM silver_orders
WHERE status <> 'batal'
GROUP BY jam
ORDER BY jam
""")

# =========================================================================
# 3. Peringkat produk
# =========================================================================
db.execute("""
CREATE TABLE gold_produk AS
SELECT
    RANK() OVER (ORDER BY SUM(o.total) DESC) AS peringkat,
    p.nama,
    p.kategori,
    SUM(o.jumlah) AS unit_terjual,
    SUM(o.total)  AS penjualan,
    SUM(o.laba)   AS laba
FROM silver_orders o
JOIN dim_products p ON p.product_id = o.product_id
WHERE o.status <> 'batal'
GROUP BY p.product_id, p.nama, p.kategori
ORDER BY peringkat
""")

db.commit()

for tabel in ("gold_kategori", "gold_per_jam", "gold_produk"):
    n = db.execute(f"SELECT COUNT(*) FROM {tabel}").fetchone()[0]
    print(f"  {tabel:16s} {n:>3} baris")

# Pemeriksaan cepat: total dari tiga sudut pandang harus sama.
a = db.execute("SELECT SUM(penjualan) FROM gold_kategori").fetchone()[0]
b = db.execute("SELECT SUM(penjualan) FROM gold_per_jam").fetchone()[0]
c = db.execute("SELECT SUM(penjualan) FROM gold_produk").fetchone()[0]
assert a == b == c, "total dari tiga tabel gold harus sama"
print(f"\n  Total dari tiga tabel cocok: Rp {a:,}")

db.close()
