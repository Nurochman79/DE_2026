"""
Pemeriksa mandiri: 21 pemeriksaan terhadap data dan hasil pipeline.

Skrip ini TIDAK dipakai saat sesi. Gunanya untuk memastikan datamu masih
waras setelah kamu mengubah aturan di 03_silver.py atau menambah tabel gold.

Jalankan setelah 01 sampai 04:  python cek_data.py
"""
import csv
import sqlite3
import sys
import io
from collections import Counter
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

REPO = Path(r"F:\programming\ngajar\advance DE\sesi 1\sesi1-pipeline")
db = sqlite3.connect(REPO / "tokobangalore.db")


def satu(sql):
    return db.execute(sql).fetchone()[0]


temuan = []


def periksa(nama, kondisi_ok, detail=""):
    status = "OK  " if kondisi_ok else "BUG "
    if not kondisi_ok:
        temuan.append(nama)
    print(f"  [{status}] {nama}{('  -> ' + detail) if detail else ''}")


print("=" * 74)
print("A. FILE CSV MENTAH")
print("=" * 74)

with (REPO / "data" / "orders.csv").open(encoding="utf-8") as f:
    orders = list(csv.DictReader(f))
with (REPO / "data" / "products.csv").open(encoding="utf-8") as f:
    products = {r["product_id"]: r for r in csv.DictReader(f)}
with (REPO / "data" / "customers.csv").open(encoding="utf-8") as f:
    customers = {r["customer_id"] for r in csv.DictReader(f)}

print(f"  orders.csv    : {len(orders)} baris")
print(f"  products.csv  : {len(products)} produk")
print(f"  customers.csv : {len(customers)} pelanggan")

kolom_kosong = [k for k in orders[0] if all(r[k] == "" for r in orders)]
periksa("tidak ada kolom yang isinya kosong semua", not kolom_kosong, str(kolom_kosong))

status_variasi = Counter(r["status"] for r in orders)
periksa("variasi penulisan status ada dan beragam", len(status_variasi) >= 8,
        f"{len(status_variasi)} variasi: {list(status_variasi)[:6]}")

waktu_terbalik = [r for r in orders if r["waktu_masuk"] < r["waktu_beli"]]
periksa("waktu_masuk tidak pernah mendahului waktu_beli", not waktu_terbalik,
        f"{len(waktu_terbalik)} baris terbalik")

cust_asing = {r["customer_id"] for r in orders
              if r["customer_id"] and r["customer_id"] not in customers}
periksa("semua customer_id ada di customers.csv", not cust_asing, str(cust_asing))

prod_asing = {r["product_id"] for r in orders if r["product_id"] not in products}
periksa("product_id asing hanya P99 (memang disengaja)", prod_asing == {"P99"},
        str(prod_asing))

harga_nol = [r for r in orders if int(r["harga_satuan"]) <= 0]
periksa("tidak ada harga_satuan nol atau minus", not harga_nol, f"{len(harga_nol)} baris")

print()
print("=" * 74)
print("B. HASIL PIPELINE DI DATABASE")
print("=" * 74)

bronze = satu("SELECT COUNT(*) FROM bronze_orders")
unik = satu("SELECT COUNT(DISTINCT order_id) FROM bronze_orders")
tolak = satu("SELECT COUNT(*) FROM data_ditolak")
silver = satu("SELECT COUNT(*) FROM silver_orders")

periksa("angka bronze/tolak/silver konsisten", unik - tolak == silver,
        f"{unik} - {tolak} = {unik - tolak}, silver = {silver}")
periksa("data_ditolak tidak punya order_id ganda",
        tolak == satu("SELECT COUNT(DISTINCT order_id) FROM data_ditolak"))
periksa("tidak ada order_id yang masuk silver DAN ditolak",
        satu("SELECT COUNT(*) FROM silver_orders s "
             "JOIN data_ditolak d ON d.order_id = s.order_id") == 0)
periksa("status di silver cuma 3 dan huruf kecil semua",
        sorted(r[0] for r in db.execute(
            "SELECT DISTINCT status FROM silver_orders")) == ["batal", "bayar", "kirim"])
periksa("tidak ada kolom NULL di silver",
        satu("SELECT COUNT(*) FROM silver_orders WHERE kategori IS NULL "
             "OR total IS NULL OR laba IS NULL OR diskon_persen IS NULL") == 0)
periksa("total = jumlah x harga_satuan, tanpa kecuali",
        satu("SELECT COUNT(*) FROM silver_orders "
             "WHERE total <> jumlah * harga_satuan") == 0)
periksa("telat_detik tidak pernah minus",
        satu("SELECT COUNT(*) FROM silver_orders WHERE telat_detik < 0") == 0)
periksa("jam hasil ekstraksi masuk akal (0-23)",
        satu("SELECT COUNT(*) FROM silver_orders WHERE jam < 0 OR jam > 23") == 0,
        f"rentang jam: {satu('SELECT MIN(jam) FROM silver_orders')}"
        f"-{satu('SELECT MAX(jam) FROM silver_orders')}")

print()
print("=" * 74)
print("C. KEWAJARAN ANGKA BISNIS")
print("=" * 74)

diskon_minus = satu("SELECT COUNT(*) FROM silver_orders WHERE diskon_persen < 0")
periksa("tidak ada diskon negatif (harga jual di atas harga normal)",
        diskon_minus == 0, f"{diskon_minus} baris")

diskon_max = satu("SELECT MAX(diskon_persen) FROM silver_orders")
periksa("diskon tidak melebihi 100 persen", diskon_max <= 100, f"maksimum {diskon_max}%")

rugi = satu("SELECT COUNT(*) FROM silver_orders WHERE laba < 0")
rugi_kategori = list(db.execute(
    "SELECT kategori, COUNT(*), SUM(laba) FROM silver_orders "
    "WHERE laba < 0 GROUP BY kategori ORDER BY 2 DESC"))
print(f"  [CEK ] transaksi yang labanya minus: {rugi} baris")
for k, n, total_rugi in rugi_kategori:
    print(f"          {k:12s} {n:>4} transaksi, rugi Rp {abs(total_rugi):,}")

margin = list(db.execute("SELECT kategori, margin_persen FROM gold_kategori"))
periksa("margin tiap kategori masih masuk akal (0-80%)",
        all(0 <= m <= 80 for _, m in margin), str(margin))

kontribusi = satu("SELECT ROUND(SUM(kontribusi_persen), 1) FROM gold_kategori")
periksa("total kontribusi kategori = 100 persen", abs(kontribusi - 100) < 0.3,
        f"jumlahnya {kontribusi}%")

a = satu("SELECT SUM(penjualan) FROM gold_kategori")
b = satu("SELECT SUM(penjualan) FROM gold_per_jam")
c = satu("SELECT SUM(penjualan) FROM gold_produk")
d = satu("SELECT SUM(total) FROM silver_orders WHERE status <> 'batal'")
periksa("total dari 3 tabel gold sama dengan silver", a == b == c == d,
        f"{a:,} / {b:,} / {c:,} / {d:,}")

kum = list(db.execute("SELECT penjualan_kumulatif FROM gold_per_jam ORDER BY jam"))
periksa("total berjalan per jam selalu naik",
        all(kum[i][0] < kum[i + 1][0] for i in range(len(kum) - 1)))
periksa("total berjalan terakhir = total penjualan", kum[-1][0] == d)

peringkat = [r[0] for r in db.execute("SELECT peringkat FROM gold_produk ORDER BY peringkat")]
periksa("peringkat produk mulai dari 1 dan urut", peringkat[0] == 1)

print()
print("=" * 74)
if temuan:
    print(f"HASIL: {len(temuan)} masalah ditemukan")
    for t in temuan:
        print(f"  - {t}")
else:
    print("HASIL: tidak ada bug. Semua pemeriksaan lolos.")
print("=" * 74)

db.close()
