# Sesi 1 — Pipeline Tokobangalore

Pipeline kecil yang jalan dari awal sampai akhir: file CSV masuk ke database,
dibersihkan dan diperkaya, lalu diringkas jadi angka penjualan dan laba.

Semua transformasinya ditulis dalam SQL. Python di sini cuma menjalankan
perintahnya. Pola seperti ini yang disebut ELT.

> **Baru pertama kali menjalankan? Buka `PANDUAN.md`.**
> Isinya langkah demi langkah, lengkap dengan tampilan layar yang seharusnya
> muncul di tiap langkah. README ini lebih cocok dipakai sebagai rujukan
> setelah kamu sekali menjalankannya.

## Yang dibutuhkan

Python 3.9 ke atas. Tidak perlu install database, SQLite sudah bawaan Python.

```bash
pip install pytest        # cuma untuk langkah pengujian
```

## Cara menjalankan

Jalankan berurutan. Tiap file mengerjakan satu hal saja.

```bash
python 01_buat_data.py      # bikin data dummy jadi 3 file CSV
python 02_bronze.py         # CSV masuk database, apa adanya
python 03_silver.py         # diseragamkan, digabung, dihitung, disaring
python 04_gold.py           # diringkas jadi angka penjualan dan laba
python 05_lihat_hasil.py    # lihat hasilnya
python 06_data_telat.py     # berapa yang hilang kalau tidak mau menunggu
python -m pytest test_pipeline.py -v
```

Hasilnya satu file `tokobangalore.db`. Buka pakai DBeaver kalau mau melihat
isinya langsung.

Penjelasan tiap langkah, tampilan layar yang seharusnya muncul, dan cara
mengatasi masalah ada di `PANDUAN.md`.

## Apa yang terjadi di tiap zona

**Bronze** — data masuk apa adanya, semua kolom disimpan sebagai teks. Tidak
ada yang diubah. Kalau nanti ada sengketa angka dengan tim lain, tabel ini
buktinya.

**Silver** — lima langkah, urut:

1. **Seragamkan.** Sistem sumber menulis status dengan 10 cara berbeda:
   `bayar`, `BAYAR `, ` Bayar`, `KIRIM`, dan seterusnya. Semuanya
   diseragamkan pakai `LOWER(TRIM(...))` jadi tiga nilai saja.
2. **Gabung.** `LEFT JOIN` ke `dim_products` untuk mengambil kategori, harga
   normal, dan harga modal.
3. **Hitung kolom turunan.** `total`, `laba`, `diskon_persen`, `tanggal`,
   `jam`, dan `telat_detik`.
4. **Buang kiriman ganda.** `order_id` jadi primary key, lalu
   `INSERT OR IGNORE`.
5. **Saring.** Yang benar-benar salah dipindah ke `data_ditolak` beserta
   alasannya.

Urutannya penting. Menyeragamkan didahulukan sebelum menyaring, supaya data
yang sebenarnya baik-baik saja tidak ikut terbuang cuma karena beda cara
menulis. Ini kesalahan yang sering terjadi di pipeline pemula.

**Gold** — tiga tabel untuk tiga pertanyaan berbeda, memakai window function
(`SUM() OVER`, `RANK() OVER`):

| Tabel | Menjawab |
| --- | --- |
| `gold_kategori` | Kategori mana yang paling untung? Termasuk margin dan kontribusi. |
| `gold_per_jam` | Jam berapa toko paling ramai? Termasuk total berjalan. |
| `gold_produk` | Produk mana yang paling laku? Termasuk peringkatnya. |

## Isi folder

| File | Untuk apa |
| --- | --- |
| `PANDUAN.md` | Langkah demi langkah, baca ini duluan |
| `README.md` | Rujukan: isi tiap zona, isi database, angka acuan |
| `01` sampai `06` | Skrip pipeline, dijalankan berurutan |
| `test_pipeline.py` | Tujuh pemeriksaan |
| `cek_data.py` | 21 pemeriksaan tambahan, dipakai kalau kamu mengubah aturan |
| `data/` | Tiga file CSV hasil langkah 1 |

## Isi database

| Tabel | Zona | Isinya |
| --- | --- | --- |
| `bronze_orders` | Bronze | Apa adanya dari CSV, semua kolom masih teks |
| `silver_orders` | Silver | Bersih, seragam, sudah diperkaya 14 kolom |
| `data_ditolak` | — | Baris yang gagal, beserta alasannya |
| `gold_kategori` | Gold | Penjualan, laba, margin, kontribusi per kategori |
| `gold_per_jam` | Gold | Penjualan per jam plus total berjalan |
| `gold_produk` | Gold | Peringkat produk |
| `dim_products` | Dimensi | 20 produk, harga jual dan harga modal |
| `dim_customers` | Dimensi | 100 pelanggan |

## Angka yang keluar (seed 42)

```
bronze           :  2053 baris masuk
cara tulis status:    10 variasi, diseragamkan jadi 3
kiriman ganda    :    53 baris
order unik       :  2000 baris
ditolak          :    90 baris
silver           :  1910 baris
lolos            : 95.5%

TOTAL PENJUALAN  Rp 630.614.700
TOTAL LABA       Rp 159.089.700   margin 25,2%
```

Seed dikunci di 42, jadi angka di laptop kamu akan sama persis dengan angka
di layar instruktur.

## Datanya sengaja tidak rapi

Di dalam `orders.csv` ada:

- **53 baris kiriman ganda** — sistem sumber mengirim ulang order yang sama
- **10 cara menulis status** — sumber tidak konsisten
- **90 baris bermasalah** — jumlah nol, `customer_id` kosong, status
  `pending` yang tidak dikenal, dan `product_id` `P99` yang tidak ada
  di katalog
- **ratusan baris telat** — datanya baru sampai 1 sampai 60 menit setelah
  transaksi

Semuanya masalah yang benar-benar muncul di pekerjaan sehari-hari.

## Yang menarik untuk didiskusikan di kelas

Jalankan `05_lihat_hasil.py`, lalu perhatikan tabel per kategori:

```
elektronik   Rp 302.259.500   margin 16,0%   kontribusi 47,9%
fashion      Rp 115.100.700   margin 45,8%   kontribusi 18,3%
```

Kategori dengan penjualan terbesar justru yang paling tipis marginnya. Angka
seperti ini tidak akan terlihat kalau pipeline hanya menjumlahkan penjualan
tanpa ikut membawa harga modal dari tabel dimensi.

## Kenapa ada transaksi yang labanya minus?

Kalau kamu query `SELECT * FROM silver_orders WHERE laba < 0`, akan muncul
48 baris. Itu bukan bug.

Diskon maksimum di data ini 25 persen, sementara beberapa produk marginnya
memang tipis:

```
Minyak Goreng 2L    normal 38.000   modal 32.000   dijual 28.500   laba -3.500
Beras Premium 5kg   normal 78.000   modal 64.000   dijual 58.500   laba -5.500
SSD 1TB             normal 1.250.000 modal 1.010.000 dijual 937.500 laba -72.500
```

Diskon 25 persen pada produk bermargin 16 persen otomatis menjual di bawah
modal. Di ritel ini kadang disengaja untuk menarik pembeli, tapi kalau tidak
dipantau bisa memakan untung.

Pertanyaan bagus untuk kelas: pipeline seperti apa yang bisa memberi tahu tim
promo bahwa diskon mereka menjual di bawah modal, sebelum promonya jalan
sebulan penuh?
